<?php

include('connect.php');

mysqli_query($con,"insert into fgot (username,code) values ('dfdf','dffd')");