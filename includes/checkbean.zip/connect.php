<?php

//$con = mysqli_connect("localhost","triplawi_lambo","1Siyabonga.","triplawi_break");
$con = mysqli_connect("localhost","triangle_siya","1Siyabonga.","triangle_break");
//$con = mysqli_connect("localhost","root","","break1");

?>